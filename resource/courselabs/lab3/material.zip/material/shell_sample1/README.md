Shell
=====

Shell scripts/programs for use in Linux Systems. (CentOS/Redhat and SUSE/openSUSE variants)

